import javax.sql.rowset.FilteredRowSet;
import java.util.Scanner;

public class Operations {
    public static void main() {

        Scanner sc = new Scanner(System.in);
        boolean flag = true;
        while (flag) {
            System.out.println("\nPlease select an option from below\n");
            FrontScreen.second();

            int opt = sc.nextInt();
            switch (opt) {

                case 1:
                    System.out.println("Enter the File Name");
                    String name=sc.next();
                    Files.CreateFile(name);
                    break;
                case 2:
                    System.out.println("Enter the file name to delete");
                    String Name= sc.next();
                    Files.Delete(Name);
                    break;
                case 3:
                    System.out.println("Enter the file name to search");
                    String NAME= sc.next();
                    Files.searchFiles(NAME);
                    break;
                case 4:
                    flag = false;
                    break;
                default:
                    System.out.println("Please Enter the Valid Input");
            }

        }

        System.out.println("\nEnd of the operations");
    }

}
