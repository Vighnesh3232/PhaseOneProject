import jdk.dynalink.Operation;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        FrontScreen obj1 = new FrontScreen();
        Scanner sc = new Scanner( System.in);
        FrontScreen.main();

        boolean flag = true;

        while (flag ){
            FrontScreen.first();
            int opt = sc.nextInt();
            switch (opt){
                case 1:
                    Files.ListAllFiles();
                    break;
                case 2:
                    Operations.main();
                    break;
                case 3:
                    flag = false;
                    break;
                default:
                    System.out.println(" please select valid options");

            }
        }


    System.out.println("End of application");
    }
}