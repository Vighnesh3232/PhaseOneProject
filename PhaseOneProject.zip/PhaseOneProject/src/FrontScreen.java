import java.util.ArrayList;

public class FrontScreen {
    public static void main() {

        String name = "\t\t\t\t\t\t       Developed::Vighnesh Gajula\n\n";
        System.out.println("\t\t\t\t\t\t****** Welcome To LockedMe.com ******\n");
        System.out.println(name);

    }
    public static void first(){
        ArrayList<String> screen= new ArrayList<String>();
        screen.add("1.Show all files in sorted order ");
        screen.add("2.Operations");
        screen.add("3.Exit");

        for(String str: screen){
            System.out.println(str);
        }

    }

    public static void second(){
        ArrayList<String> screen= new ArrayList<String>();
        screen.add("1.Add a file to the Directory ");
        screen.add("2.Delete a file from Directory");
        screen.add("3.Search a file in the Directory");
        screen.add("4.Move to the main menu");

        for(String str: screen){
            System.out.println(str);
        }
    }

    public void screen1(ArrayList<String> opt){
        for(String str : opt ){
            System.out.println(str);
        }

    }
}
